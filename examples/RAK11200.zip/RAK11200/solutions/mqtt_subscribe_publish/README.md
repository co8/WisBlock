When the device is powered on, the log is as follows:

![image-20210312161920223](assets/image-20210312161920223.png)



configure [mqtt.fx]([Download (jensd.de)](http://www.mqttfx.jensd.de/index.php/download)) to connect mqtt broker.

![mqtt-fx-config](assets/mqtt-fx-config.png)



configure mqtt.fx to subscribe specific topics.

![image-20210312161431163](assets/image-20210312161431163.png)



Publish topic to control LED on/off.

![image-20210312161454851](assets/image-20210312161454851.png)



![image-20210312161602378](assets/image-20210312161602378.png)



Publish topic to control LED off.

![image-20210312161713024](assets/image-20210312161713024.png)

Arduino log is as follows.

![image-20210312161740431](assets/image-20210312161740431.png)